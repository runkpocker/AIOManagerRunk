# AIOManager Nuvio Collection Manager integration

## What was added

- `/nuvio` dashboard served by the existing Fastify process.
- **Collections** shortcut beside the TorBox **Renamer** shortcut.
- Manifest registry with encrypted-at-rest URLs.
- Catalog scanning, automatic classification, review queue, folder thumbnail/title editing, validated JSON builds, and build history.
- Existing AIOManager login and database are reused; data is scoped by AIOManager cloud account ID.
- A future Nuvio provider boundary at `server/nuvio/providers/nuvio-provider.js` for:
  - Nuvio account authentication;
  - pulling installed add-ons/manifests;
  - pushing collection JSON back to Nuvio.

Those future API actions are deliberately disabled until a supported Nuvio API contract is available.

## Files added

```text
server/nuvio/
├── index.js
├── auth.js
├── builder.js
├── classifier.js
├── utils.js
├── ui.html
├── providers/
│   └── nuvio-provider.js
└── seed/
    ├── recommended.json
    └── tpb_master_catalog_list.json
```

## Files changed

```text
server/index.js
src/components/layout/Header.tsx
.env.example
README.md
```

## Git installation

### Complete-repository package

Replace the contents of your local repository with the complete package, preserving your `.git` directory if it is already cloned.

### Overlay package

Alternatively, extract the overlay directly into the repository root and allow it to overwrite the listed files.

Then run:

```bash
npm install
npm run build
git add .
git commit -m "Add Nuvio Collection Manager module"
git push
```

## Railway changes

### Required

No new Railway service, domain, database, start command, or environment variable is required.

The existing root `Dockerfile` still builds and runs the app. The Nuvio module uses the existing AIOManager database:

- SQLite: existing `/app/data/aio.db`
- PostgreSQL: existing `DATABASE_URL`

### Check only if using SQLite

Confirm the current AIOManager service already has a persistent Railway volume mounted at:

```text
/app/data
```

Without a persistent volume, both existing AIOManager data and Nuvio data can disappear during redeployment.

### Optional variables

```text
NUVIO_REQUEST_TIMEOUT_MS=25000
NUVIO_ALLOW_PRIVATE_MANIFESTS=false
NUVIO_MAX_MANIFEST_BYTES=2000000
```

The defaults are already built in. Do not enable private manifests on a public deployment unless you intentionally need LAN/private-address URLs.

## First use

1. Sign into AIOManager normally.
2. Click **Collections** beside **Renamer**.
3. Add the seven manifest URLs through the Nuvio dashboard.
4. Click **Scan all enabled**.
5. Resolve anything in **Review**.
6. Open **Builds** and select **Validate and build**.
7. Download and import the resulting JSON into Nuvio.

Manifest URLs are not committed in the seed files and are encrypted in the database when entered through the dashboard.

## Validation performed

- Node syntax checks passed for all new server modules and the modified server entry point.
- Browser JavaScript syntax check passed for the Nuvio dashboard.
- Classification checks passed for required search, category filters, recent feeds, unknown review, and all 107 known studio catalogs.
- Collection build/merge validation passed against the bundled five-collection, 48-folder seed.

A full `npm ci`/Docker build could not be completed in the artifact environment because its npm package mirror returned HTTP 503. No new npm dependency was added, so Railway will use the existing lockfile and dependency set.
