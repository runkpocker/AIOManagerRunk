export function createOwnerAuth({ db, decrypt, fallbackKeys }) {
  return async function requireOwner(request, reply) {
    const ownerId = String(request.headers['x-sync-id'] || '')
    const token = String(request.headers['x-sync-password'] || '')
    if (!ownerId || !token) {
      reply.code(401)
      return null
    }
    const row = await db.get('SELECT password FROM kv_store WHERE key = $1', [ownerId])
    if (!row) {
      reply.code(401)
      return null
    }
    let expected
    try {
      expected = decrypt(row.password, fallbackKeys)
    } catch {
      reply.code(401)
      return null
    }
    if (expected !== token) {
      reply.code(401)
      return null
    }
    return ownerId
  }
}
