/**
 * Future Nuvio account integration boundary.
 *
 * Do not wire this to guessed or undocumented endpoints. Once Nuvio exposes a
 * stable account API, implement these methods without changing the scanner,
 * classifier, builder, database schema, or dashboard routes.
 */
export class NuvioProvider {
  constructor({ db, encrypt, decrypt, primaryKey, fallbackKeys }) {
    this.db = db
    this.encrypt = encrypt
    this.decrypt = decrypt
    this.primaryKey = primaryKey
    this.fallbackKeys = fallbackKeys
  }

  async status(ownerId) {
    const row = await this.db.get(
      'SELECT provider, status, updated_at FROM nuvio_connections WHERE owner_id = $1 AND provider = $2',
      [ownerId, 'nuvio'],
    )
    return {
      available: false,
      connected: row?.status === 'connected',
      provider: 'nuvio',
      mode: 'manual',
      message: 'Nuvio account API integration is scaffolded but disabled until a stable supported API is available.',
      updatedAt: row?.updated_at || null,
    }
  }

  async connect() {
    const error = new Error('Nuvio account authentication is not implemented because no supported API contract is configured.')
    error.statusCode = 501
    throw error
  }

  async pullAddons() {
    const error = new Error('Automatic add-on import from Nuvio is not available yet. Add manifest URLs manually.')
    error.statusCode = 501
    throw error
  }

  async pushCollections() {
    const error = new Error('Automatic collection push to Nuvio is not available yet. Download and import the generated JSON manually.')
    error.statusCode = 501
    throw error
  }
}
