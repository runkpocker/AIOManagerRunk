import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { jsonParse, normalize } from './utils.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const SEED = JSON.parse(fs.readFileSync(path.join(__dirname, 'seed', 'recommended.json'), 'utf8'))
const MASTER = JSON.parse(fs.readFileSync(path.join(__dirname, 'seed', 'tpb_master_catalog_list.json'), 'utf8'))

const folderByTitle = new Map()
const folderById = new Map()
const exactSeedCatalogs = new Set()
const catalogToFolder = new Map()
for (const collection of SEED) {
  for (const folder of collection.folders || []) {
    folderByTitle.set(normalize(folder.title), { collectionId: collection.id, folderId: folder.id, title: folder.title })
    folderById.set(folder.id, { collectionId: collection.id, folderId: folder.id, title: folder.title })
    for (const source of folder.catalogSources || []) {
      exactSeedCatalogs.add(`${source.addonId}|${source.catalogId}|${source.type}`)
      if (!catalogToFolder.has(source.catalogId)) catalogToFolder.set(source.catalogId, folder.title)
    }
  }
}

const studioFolderByName = new Map()
for (const catalog of MASTER.catalogs || []) {
  if (catalog.Group !== 'Studio') continue
  const folderTitle = catalogToFolder.get(catalog['Catalog ID'])
  if (folderTitle) {
    studioFolderByName.set(normalize(catalog.Name), folderTitle)
    studioFolderByName.set(normalize(catalog['Catalog ID']), folderTitle)
  }
}

const categoryAliases = new Map([
  ['lesbians', 'Lesbian'],
  ['lesbian', 'Lesbian'],
  ['bigtits', 'Big Tits'],
  ['bigboobs', 'Big Tits'],
  ['bigass', 'Big Ass'],
  ['doublepenetration', 'Double Penetration'],
  ['dp', 'Double Penetration'],
  ['deepthroat', 'Deepthroat'],
  ['deepthroating', 'Deepthroat'],
  ['interracial', 'Interracial'],
  ['pov', 'POV'],
  ['milf', 'MILF'],
  ['mature', 'Mature'],
  ['anal', 'Anal'],
  ['threesome', 'Threesome'],
  ['creampie', 'Creampie'],
  ['asian', 'Asian'],
  ['latina', 'Latina'],
  ['ebony', 'Ebony'],
  ['hardcore', 'Hardcore'],
  ['public', 'Public'],
  ['cosplay', 'Cosplay'],
  ['bdsm', 'BDSM'],
  ['massage', 'Massage'],
  ['facial', 'Facial'],
  ['orgy', 'Orgy'],
  ['bbw', 'BBW'],
  ['tattoo', 'Tattoo'],
  ['cuckold', 'Cuckold'],
  ['voyeur', 'Voyeur'],
  ['blowjob', 'Blowjob'],
  ['gangbang', 'Gangbang'],
])

function folderAssignment(title, genre = null) {
  const folder = folderByTitle.get(normalize(title))
  return folder ? [{ ...folder, genre }] : []
}

function extras(catalog) {
  return new Map((catalog.extra || []).filter(Boolean).map((item) => [item.name, item]))
}

export function getSeedCollections() {
  return structuredClone(SEED)
}

export function getFolderOptions(collections = SEED) {
  return collections.flatMap((collection) => (collection.folders || []).map((folder) => ({
    collectionId: collection.id,
    collectionTitle: collection.title,
    folderId: folder.id,
    folderTitle: folder.title,
  })))
}

export function classifyCatalog({ addonId, catalog, override = null }) {
  if (override) {
    if (override.decision === 'exclude' || override.decision === 'search_only') {
      return { decision: override.decision, reason: 'Manual override', assignments: [] }
    }
    if (override.decision === 'assign' && override.folder_id) {
      const folder = folderById.get(override.folder_id)
      if (folder) {
        return {
          decision: 'assigned',
          reason: 'Manual assignment',
          assignments: [{ ...folder, collectionId: override.collection_id || folder.collectionId, genre: override.genre || null }],
        }
      }
    }
  }

  const exactKey = `${addonId}|${catalog.id}|${catalog.type}`
  if (exactSeedCatalogs.has(exactKey)) {
    return { decision: 'seed', reason: 'Already represented in the bundled collection architecture', assignments: [] }
  }

  const extraMap = extras(catalog)
  if (extraMap.get('search')?.isRequired === true) {
    return { decision: 'search_only', reason: 'Catalog requires a runtime search term', assignments: [] }
  }

  const genreExtra = extraMap.get('genre')
  const genreOptions = Array.isArray(genreExtra?.options) ? genreExtra.options : []
  if (genreOptions.length) {
    const assignments = []
    const seen = new Set()
    for (const option of genreOptions) {
      const alias = categoryAliases.get(normalize(option))
      if (!alias) continue
      const folder = folderByTitle.get(normalize(alias))
      if (!folder) continue
      const key = `${folder.folderId}|${option}`
      if (!seen.has(key)) {
        assignments.push({ ...folder, genre: option })
        seen.add(key)
      }
    }
    if (assignments.length) {
      return { decision: 'auto', reason: `Matched ${assignments.length} supported category filters`, assignments }
    }
  }

  const nameKey = normalize(catalog.name || catalog.id)
  const idKey = normalize(catalog.id)
  const studioFolder = studioFolderByName.get(nameKey) || studioFolderByName.get(idKey)
  if (studioFolder) {
    return { decision: 'auto', reason: `Known studio mapped to ${studioFolder}`, assignments: folderAssignment(studioFolder) }
  }

  const combined = `${String(catalog.id || '').toLowerCase()} ${String(catalog.name || '').toLowerCase()}`
  if (/hentai/.test(combined)) {
    if (/(recent|latest|new|top|popular)/.test(combined)) {
      return { decision: 'auto', reason: 'Hentai discovery feed', assignments: folderAssignment('Hentai · Fresh & Top') }
    }
    if (/(all|full|library)/.test(combined)) {
      return { decision: 'auto', reason: 'Full hentai library', assignments: folderAssignment('Hentai · Full Library') }
    }
  }
  if (/(live|webcam|camgirls|cam_girls|couples)/.test(combined)) {
    return { decision: 'auto', reason: 'Live catalog', assignments: folderAssignment('Live') }
  }
  if (/(recent|latest|new|newest|fresh|releases)/.test(combined)) {
    return { decision: 'auto', reason: 'Recent or new releases feed', assignments: folderAssignment('Fresh Releases') }
  }
  if (/^(all|full|catalog|library)$/.test(nameKey) || /(full catalog|all scenes|complete library)/.test(combined)) {
    return { decision: 'auto', reason: 'Full catalog feed', assignments: folderAssignment('Full Adult Catalog') }
  }

  return { decision: 'review', reason: 'No safe automatic rule matched', assignments: [] }
}

export function parseAssignments(value) {
  const parsed = jsonParse(value, [])
  return Array.isArray(parsed) ? parsed : []
}
