import crypto from 'crypto'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { createOwnerAuth } from './auth.js'
import { buildCollections, loadCollectionConfig, saveCollectionConfig } from './builder.js'
import { classifyCatalog, getFolderOptions, getSeedCollections } from './classifier.js'
import { fetchManifest, jsonParse, makeId, now } from './utils.js'
import { NuvioProvider } from './providers/nuvio-provider.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const UI_HTML = fs.readFileSync(path.join(__dirname, 'ui.html'), 'utf8')

function urlHash(url) {
  return crypto.createHash('sha256').update(url).digest('hex')
}

function maskUrl(rawUrl) {
  try {
    const url = new URL(rawUrl)
    const parts = url.pathname.split('/').filter(Boolean)
    const safeParts = parts.map((part, index) => {
      if (index === parts.length - 1 && part === 'manifest.json') return part
      if (part.length > 8) return `${part.slice(0, 3)}…${part.slice(-2)}`
      return part
    })
    return `${url.origin}/${safeParts.join('/')}`
  } catch {
    return 'Stored manifest URL'
  }
}

function parseBulkInput(input = '') {
  return String(input)
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const separator = line.indexOf('|')
      if (separator > 0) {
        return { displayName: line.slice(0, separator).trim(), manifestUrl: line.slice(separator + 1).trim() }
      }
      return { displayName: '', manifestUrl: line }
    })
}

export default async function nuvioPlugin(fastify, options) {
  const { db, encrypt, decrypt, primaryKey, fallbackKeys } = options
  if (!db || !encrypt || !decrypt || !primaryKey || !fallbackKeys) {
    throw new Error('Nuvio plugin requires db and encryption services')
  }

  const requireOwner = createOwnerAuth({ db, decrypt, fallbackKeys })
  const provider = new NuvioProvider({ db, encrypt, decrypt, primaryKey, fallbackKeys })
  const requestTimeoutMs = Number(process.env.NUVIO_REQUEST_TIMEOUT_MS || 25000)
  const allowPrivate = process.env.NUVIO_ALLOW_PRIVATE_MANIFESTS === 'true'
  const maxManifestBytes = Number(process.env.NUVIO_MAX_MANIFEST_BYTES || 2_000_000)

  await db.exec(`
    CREATE TABLE IF NOT EXISTS nuvio_addons (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL,
      display_name TEXT NOT NULL,
      manifest_url_enc TEXT NOT NULL,
      manifest_url_hash TEXT NOT NULL,
      addon_id TEXT,
      addon_name TEXT,
      version TEXT,
      enabled INTEGER NOT NULL DEFAULT 1,
      manifest_json TEXT,
      last_scanned_at BIGINT,
      last_error TEXT,
      created_at BIGINT NOT NULL,
      updated_at BIGINT NOT NULL,
      UNIQUE(owner_id, manifest_url_hash)
    );

    CREATE TABLE IF NOT EXISTS nuvio_catalogs (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL,
      addon_record_id TEXT NOT NULL,
      addon_id TEXT NOT NULL,
      catalog_id TEXT NOT NULL,
      type TEXT NOT NULL,
      name TEXT NOT NULL,
      extra_json TEXT,
      decision TEXT NOT NULL,
      reason TEXT,
      assignments_json TEXT,
      active INTEGER NOT NULL DEFAULT 1,
      discovered_at BIGINT NOT NULL,
      updated_at BIGINT NOT NULL,
      UNIQUE(owner_id, addon_record_id, catalog_id, type)
    );

    CREATE TABLE IF NOT EXISTS nuvio_overrides (
      owner_id TEXT NOT NULL,
      addon_id TEXT NOT NULL,
      catalog_id TEXT NOT NULL,
      type TEXT NOT NULL,
      decision TEXT NOT NULL,
      collection_id TEXT,
      folder_id TEXT,
      genre TEXT,
      reason TEXT,
      updated_at BIGINT NOT NULL,
      PRIMARY KEY(owner_id, addon_id, catalog_id, type)
    );

    CREATE TABLE IF NOT EXISTS nuvio_collection_config (
      owner_id TEXT PRIMARY KEY,
      json_text TEXT NOT NULL,
      updated_at BIGINT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS nuvio_builds (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL,
      json_text TEXT NOT NULL,
      summary_json TEXT NOT NULL,
      created_at BIGINT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS nuvio_connections (
      owner_id TEXT NOT NULL,
      provider TEXT NOT NULL,
      status TEXT NOT NULL,
      encrypted_config TEXT,
      updated_at BIGINT NOT NULL,
      PRIMARY KEY(owner_id, provider)
    );

    CREATE INDEX IF NOT EXISTS idx_nuvio_addons_owner ON nuvio_addons(owner_id);
    CREATE INDEX IF NOT EXISTS idx_nuvio_catalogs_owner ON nuvio_catalogs(owner_id, active, decision);
    CREATE INDEX IF NOT EXISTS idx_nuvio_builds_owner ON nuvio_builds(owner_id, created_at);
  `)

  async function ownerPreHandler(request, reply) {
    const ownerId = await requireOwner(request, reply)
    if (!ownerId) return reply.send({ error: 'Unauthorized' })
    request.nuvioOwnerId = ownerId
  }

  async function addManifest(ownerId, displayName, manifestUrl) {
    const cleanUrl = String(manifestUrl || '').trim()
    if (!cleanUrl) throw new Error('Manifest URL is required')
    const parsed = new URL(cleanUrl)
    if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('Manifest URL must use HTTP or HTTPS')
    const id = crypto.randomUUID()
    const stamp = now()
    const label = String(displayName || '').trim() || parsed.hostname
    await db.run(
      `INSERT INTO nuvio_addons(
        id, owner_id, display_name, manifest_url_enc, manifest_url_hash,
        enabled, created_at, updated_at
       ) VALUES ($1,$2,$3,$4,$5,1,$6,$7)
       ON CONFLICT(owner_id, manifest_url_hash) DO UPDATE SET
         display_name = excluded.display_name,
         manifest_url_enc = excluded.manifest_url_enc,
         enabled = 1,
         updated_at = excluded.updated_at`,
      [id, ownerId, label, encrypt(cleanUrl, primaryKey), urlHash(cleanUrl), stamp, stamp],
    )
  }

  async function scanAddon(ownerId, addonRecord) {
    const manifestUrl = decrypt(addonRecord.manifest_url_enc, fallbackKeys)
    const manifest = await fetchManifest(manifestUrl, {
      timeoutMs: requestTimeoutMs,
      allowPrivate,
      maxBytes: maxManifestBytes,
    })
    const stamp = now()
    await db.run(
      `UPDATE nuvio_addons SET addon_id=$1, addon_name=$2, version=$3, manifest_json=$4,
       last_scanned_at=$5, last_error=NULL, updated_at=$6 WHERE id=$7 AND owner_id=$8`,
      [manifest.id, manifest.name || addonRecord.display_name, manifest.version || '', JSON.stringify(manifest), stamp, stamp, addonRecord.id, ownerId],
    )
    await db.run('UPDATE nuvio_catalogs SET active=0, updated_at=$1 WHERE owner_id=$2 AND addon_record_id=$3', [stamp, ownerId, addonRecord.id])

    const stats = { total: 0, seed: 0, auto: 0, assigned: 0, review: 0, search_only: 0, exclude: 0 }
    for (const catalog of manifest.catalogs || []) {
      if (!catalog?.id || !catalog?.type) continue
      const override = await db.get(
        `SELECT * FROM nuvio_overrides WHERE owner_id=$1 AND addon_id=$2 AND catalog_id=$3 AND type=$4`,
        [ownerId, manifest.id, catalog.id, catalog.type],
      )
      const result = classifyCatalog({ addonId: manifest.id, catalog, override })
      const catalogRowId = makeId(ownerId, addonRecord.id, catalog.id, catalog.type)
      await db.run(
        `INSERT INTO nuvio_catalogs(
          id, owner_id, addon_record_id, addon_id, catalog_id, type, name, extra_json,
          decision, reason, assignments_json, active, discovered_at, updated_at
         ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,1,$12,$13)
         ON CONFLICT(id) DO UPDATE SET
          addon_id=excluded.addon_id, name=excluded.name, extra_json=excluded.extra_json,
          decision=excluded.decision, reason=excluded.reason, assignments_json=excluded.assignments_json,
          active=1, updated_at=excluded.updated_at`,
        [
          catalogRowId, ownerId, addonRecord.id, manifest.id, catalog.id, catalog.type,
          catalog.name || catalog.id, JSON.stringify(catalog.extra || []), result.decision,
          result.reason, JSON.stringify(result.assignments || []), stamp, stamp,
        ],
      )
      stats.total++
      stats[result.decision] = (stats[result.decision] || 0) + 1
    }
    return stats
  }

  fastify.get('/nuvio', async (_request, reply) => reply.type('text/html; charset=utf-8').send(UI_HTML))

  fastify.get('/api/nuvio/status', { preHandler: ownerPreHandler }, async (request) => {
    const ownerId = request.nuvioOwnerId
    const [addons, catalogs, review, builds] = await Promise.all([
      db.get('SELECT COUNT(*) AS count FROM nuvio_addons WHERE owner_id=$1', [ownerId]),
      db.get('SELECT COUNT(*) AS count FROM nuvio_catalogs WHERE owner_id=$1 AND active=1', [ownerId]),
      db.get("SELECT COUNT(*) AS count FROM nuvio_catalogs WHERE owner_id=$1 AND active=1 AND decision='review'", [ownerId]),
      db.get('SELECT COUNT(*) AS count FROM nuvio_builds WHERE owner_id=$1', [ownerId]),
    ])
    return {
      addons: Number(addons?.count || 0),
      catalogs: Number(catalogs?.count || 0),
      review: Number(review?.count || 0),
      builds: Number(builds?.count || 0),
    }
  })

  fastify.get('/api/nuvio/addons', { preHandler: ownerPreHandler }, async (request) => {
    const rows = await db.query('SELECT * FROM nuvio_addons WHERE owner_id=$1 ORDER BY created_at ASC', [request.nuvioOwnerId])
    return rows.map((row) => ({
      id: row.id,
      displayName: row.display_name,
      manifestUrl: maskUrl(decrypt(row.manifest_url_enc, fallbackKeys)),
      addonId: row.addon_id,
      addonName: row.addon_name,
      version: row.version,
      enabled: Boolean(row.enabled),
      lastScannedAt: row.last_scanned_at,
      lastError: row.last_error,
    }))
  })

  fastify.post('/api/nuvio/addons', { preHandler: ownerPreHandler }, async (request, reply) => {
    try {
      await addManifest(request.nuvioOwnerId, request.body?.displayName, request.body?.manifestUrl)
      return { success: true }
    } catch (error) {
      reply.code(400)
      return { error: error.message }
    }
  })

  fastify.post('/api/nuvio/addons/bulk', { preHandler: ownerPreHandler }, async (request, reply) => {
    const entries = parseBulkInput(request.body?.input)
    if (!entries.length) {
      reply.code(400)
      return { error: 'Paste at least one manifest URL' }
    }
    const errors = []
    let added = 0
    for (const entry of entries) {
      try {
        await addManifest(request.nuvioOwnerId, entry.displayName, entry.manifestUrl)
        added++
      } catch (error) {
        errors.push(`${entry.manifestUrl}: ${error.message}`)
      }
    }
    return { success: errors.length === 0, added, errors }
  })

  fastify.delete('/api/nuvio/addons/:id', { preHandler: ownerPreHandler }, async (request) => {
    const ownerId = request.nuvioOwnerId
    await db.run('DELETE FROM nuvio_catalogs WHERE owner_id=$1 AND addon_record_id=$2', [ownerId, request.params.id])
    await db.run('DELETE FROM nuvio_addons WHERE owner_id=$1 AND id=$2', [ownerId, request.params.id])
    return { success: true }
  })

  fastify.post('/api/nuvio/addons/:id/scan', { preHandler: ownerPreHandler }, async (request, reply) => {
    const addon = await db.get('SELECT * FROM nuvio_addons WHERE owner_id=$1 AND id=$2', [request.nuvioOwnerId, request.params.id])
    if (!addon) {
      reply.code(404)
      return { error: 'Add-on not found' }
    }
    try {
      const stats = await scanAddon(request.nuvioOwnerId, addon)
      return { success: true, stats }
    } catch (error) {
      await db.run('UPDATE nuvio_addons SET last_error=$1, updated_at=$2 WHERE owner_id=$3 AND id=$4', [error.message, now(), request.nuvioOwnerId, addon.id])
      reply.code(400)
      return { error: error.message }
    }
  })

  fastify.post('/api/nuvio/addons/scan-all', { preHandler: ownerPreHandler }, async (request) => {
    const addons = await db.query('SELECT * FROM nuvio_addons WHERE owner_id=$1 AND enabled=1 ORDER BY created_at ASC', [request.nuvioOwnerId])
    const results = []
    for (const addon of addons) {
      try {
        results.push({ id: addon.id, name: addon.display_name, success: true, stats: await scanAddon(request.nuvioOwnerId, addon) })
      } catch (error) {
        await db.run('UPDATE nuvio_addons SET last_error=$1, updated_at=$2 WHERE owner_id=$3 AND id=$4', [error.message, now(), request.nuvioOwnerId, addon.id])
        results.push({ id: addon.id, name: addon.display_name, success: false, error: error.message })
      }
    }
    return { success: results.every((item) => item.success), results }
  })

  fastify.get('/api/nuvio/catalogs', { preHandler: ownerPreHandler }, async (request) => {
    const decision = String(request.query?.decision || '')
    const params = [request.nuvioOwnerId]
    let sql = `SELECT id, addon_id, catalog_id, type, name, decision, reason, assignments_json, extra_json
               FROM nuvio_catalogs WHERE owner_id=$1 AND active=1`
    if (decision) {
      sql += ' AND decision=$2'
      params.push(decision)
    }
    sql += ' ORDER BY addon_id, name'
    const rows = await db.query(sql, params)
    return rows.map((row) => ({
      id: row.id,
      addonId: row.addon_id,
      catalogId: row.catalog_id,
      type: row.type,
      name: row.name,
      decision: row.decision,
      reason: row.reason,
      assignments: jsonParse(row.assignments_json, []),
      extra: jsonParse(row.extra_json, []),
    }))
  })

  fastify.post('/api/nuvio/catalogs/:id/decision', { preHandler: ownerPreHandler }, async (request, reply) => {
    const row = await db.get('SELECT * FROM nuvio_catalogs WHERE owner_id=$1 AND id=$2', [request.nuvioOwnerId, request.params.id])
    if (!row) {
      reply.code(404)
      return { error: 'Catalog not found' }
    }
    const decision = String(request.body?.decision || '')
    if (decision === 'auto') {
      await db.run('DELETE FROM nuvio_overrides WHERE owner_id=$1 AND addon_id=$2 AND catalog_id=$3 AND type=$4', [request.nuvioOwnerId, row.addon_id, row.catalog_id, row.type])
      const result = classifyCatalog({
        addonId: row.addon_id,
        catalog: { id: row.catalog_id, type: row.type, name: row.name, extra: jsonParse(row.extra_json, []) },
      })
      await db.run('UPDATE nuvio_catalogs SET decision=$1, reason=$2, assignments_json=$3, updated_at=$4 WHERE id=$5', [result.decision, result.reason, JSON.stringify(result.assignments), now(), row.id])
      return { success: true, decision: result.decision }
    }
    if (!['assign', 'exclude', 'search_only'].includes(decision)) {
      reply.code(400)
      return { error: 'Invalid decision' }
    }
    if (decision === 'assign' && (!request.body?.collectionId || !request.body?.folderId)) {
      reply.code(400)
      return { error: 'Choose a collection folder' }
    }
    await db.run(
      `INSERT INTO nuvio_overrides(owner_id, addon_id, catalog_id, type, decision, collection_id, folder_id, genre, reason, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       ON CONFLICT(owner_id, addon_id, catalog_id, type) DO UPDATE SET
        decision=excluded.decision, collection_id=excluded.collection_id, folder_id=excluded.folder_id,
        genre=excluded.genre, reason=excluded.reason, updated_at=excluded.updated_at`,
      [
        request.nuvioOwnerId, row.addon_id, row.catalog_id, row.type, decision,
        request.body?.collectionId || null, request.body?.folderId || null,
        request.body?.genre || null, request.body?.reason || 'Manual decision', now(),
      ],
    )
    const assignments = decision === 'assign' ? [{
      collectionId: request.body.collectionId,
      folderId: request.body.folderId,
      genre: request.body.genre || null,
    }] : []
    await db.run('UPDATE nuvio_catalogs SET decision=$1, reason=$2, assignments_json=$3, updated_at=$4 WHERE id=$5', [decision === 'assign' ? 'assigned' : decision, 'Manual decision', JSON.stringify(assignments), now(), row.id])
    return { success: true }
  })

  fastify.get('/api/nuvio/collections', { preHandler: ownerPreHandler }, async (request) => {
    const collections = await loadCollectionConfig(db, request.nuvioOwnerId)
    return { collections, folders: getFolderOptions(collections) }
  })

  fastify.put('/api/nuvio/collections', { preHandler: ownerPreHandler }, async (request, reply) => {
    try {
      await saveCollectionConfig(db, request.nuvioOwnerId, request.body?.collections)
      return { success: true }
    } catch (error) {
      reply.code(400)
      return { error: error.message }
    }
  })

  fastify.post('/api/nuvio/collections/reset', { preHandler: ownerPreHandler }, async (request) => {
    await db.run('DELETE FROM nuvio_collection_config WHERE owner_id=$1', [request.nuvioOwnerId])
    return { success: true, collections: getSeedCollections() }
  })

  fastify.post('/api/nuvio/builds', { preHandler: ownerPreHandler }, async (request, reply) => {
    const { collections, summary } = await buildCollections(db, request.nuvioOwnerId)
    if (summary.validationErrors.length) {
      reply.code(400)
      return { error: summary.validationErrors.join('; '), summary }
    }
    const id = crypto.randomUUID()
    await db.run(
      'INSERT INTO nuvio_builds(id, owner_id, json_text, summary_json, created_at) VALUES ($1,$2,$3,$4,$5)',
      [id, request.nuvioOwnerId, JSON.stringify(collections, null, 2), JSON.stringify(summary), now()],
    )
    return { success: true, id, summary }
  })

  fastify.get('/api/nuvio/builds', { preHandler: ownerPreHandler }, async (request) => {
    const rows = await db.query('SELECT id, summary_json, created_at FROM nuvio_builds WHERE owner_id=$1 ORDER BY created_at DESC LIMIT 30', [request.nuvioOwnerId])
    return rows.map((row) => ({ id: row.id, summary: jsonParse(row.summary_json, {}), createdAt: row.created_at }))
  })

  fastify.get('/api/nuvio/builds/:id/download', { preHandler: ownerPreHandler }, async (request, reply) => {
    const row = await db.get('SELECT json_text, created_at FROM nuvio_builds WHERE owner_id=$1 AND id=$2', [request.nuvioOwnerId, request.params.id])
    if (!row) {
      reply.code(404)
      return { error: 'Build not found' }
    }
    const date = new Date(Number(row.created_at)).toISOString().slice(0, 10)
    reply.header('content-disposition', `attachment; filename="nuvio-collections-${date}.json"`)
    return reply.type('application/json; charset=utf-8').send(row.json_text)
  })

  fastify.get('/api/nuvio/integration/status', { preHandler: ownerPreHandler }, async (request) => provider.status(request.nuvioOwnerId))

  for (const route of ['connect', 'pull-addons', 'push-collections']) {
    fastify.post(`/api/nuvio/integration/${route}`, { preHandler: ownerPreHandler }, async (request, reply) => {
      try {
        const method = route === 'pull-addons' ? 'pullAddons' : route === 'push-collections' ? 'pushCollections' : 'connect'
        return await provider[method](request.nuvioOwnerId, request.body)
      } catch (error) {
        reply.code(error.statusCode || 500)
        return { error: error.message }
      }
    })
  }

  fastify.log.info({ category: 'Nuvio' }, 'Nuvio Collection Manager registered at /nuvio')
}
