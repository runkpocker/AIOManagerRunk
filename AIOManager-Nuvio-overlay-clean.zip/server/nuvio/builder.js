import { getSeedCollections, parseAssignments } from './classifier.js'
import { jsonParse, now, sourceKey } from './utils.js'

export async function loadCollectionConfig(db, ownerId) {
  const row = await db.get('SELECT json_text FROM nuvio_collection_config WHERE owner_id = $1', [ownerId])
  const parsed = jsonParse(row?.json_text, null)
  return Array.isArray(parsed) ? parsed : getSeedCollections()
}

export function validateCollections(collections) {
  const errors = []
  if (!Array.isArray(collections) || collections.length === 0) return ['Collection JSON must be a non-empty array']
  const collectionIds = new Set()
  const folderIds = new Set()
  for (const collection of collections) {
    if (!collection?.id || !collection?.title || !Array.isArray(collection.folders)) {
      errors.push('Every collection must have id, title and folders')
      continue
    }
    if (collectionIds.has(collection.id)) errors.push(`Duplicate collection id: ${collection.id}`)
    collectionIds.add(collection.id)
    for (const folder of collection.folders) {
      if (!folder?.id || !folder?.title) errors.push(`Invalid folder in ${collection.title}`)
      if (folderIds.has(folder.id)) errors.push(`Duplicate folder id: ${folder.id}`)
      folderIds.add(folder.id)
    }
  }
  return errors
}

export async function saveCollectionConfig(db, ownerId, collections) {
  const errors = validateCollections(collections)
  if (errors.length) throw new Error(errors.join('; '))
  await db.run(
    `INSERT INTO nuvio_collection_config(owner_id, json_text, updated_at)
     VALUES ($1, $2, $3)
     ON CONFLICT(owner_id) DO UPDATE SET json_text = excluded.json_text, updated_at = excluded.updated_at`,
    [ownerId, JSON.stringify(collections), now()],
  )
}

export async function buildCollections(db, ownerId) {
  const collections = structuredClone(await loadCollectionConfig(db, ownerId))
  const folderMap = new Map()
  for (const collection of collections) {
    for (const folder of collection.folders || []) folderMap.set(folder.id, folder)
  }

  const rows = await db.query(
    `SELECT addon_id, catalog_id, type, decision, assignments_json
     FROM nuvio_catalogs
     WHERE owner_id = $1 AND active = 1 AND decision IN ('auto', 'assigned')`,
    [ownerId],
  )

  let sourcesAdded = 0
  let duplicatesIgnored = 0
  let missingFolders = 0
  for (const row of rows) {
    for (const assignment of parseAssignments(row.assignments_json)) {
      const folder = folderMap.get(assignment.folderId)
      if (!folder) {
        missingFolders++
        continue
      }
      const source = {
        addonId: row.addon_id,
        catalogId: row.catalog_id,
        type: row.type,
      }
      if (assignment.genre) source.genre = assignment.genre
      const existing = folder.catalogSources || []
      const keys = new Set(existing.map(sourceKey))
      if (keys.has(sourceKey(source))) {
        duplicatesIgnored++
        continue
      }
      folder.catalogSources = [...existing, source]
      folder.sources = [...(folder.sources || []), { provider: 'addon', ...source }]
      sourcesAdded++
    }
  }

  const reviewRow = await db.get(
    `SELECT COUNT(*) AS count FROM nuvio_catalogs WHERE owner_id = $1 AND active = 1 AND decision = 'review'`,
    [ownerId],
  )
  const searchRow = await db.get(
    `SELECT COUNT(*) AS count FROM nuvio_catalogs WHERE owner_id = $1 AND active = 1 AND decision = 'search_only'`,
    [ownerId],
  )
  const errors = validateCollections(collections)
  const summary = {
    collections: collections.length,
    folders: collections.reduce((total, item) => total + (item.folders?.length || 0), 0),
    sourcesAdded,
    duplicatesIgnored,
    missingFolders,
    reviewRequired: Number(reviewRow?.count || 0),
    searchOnly: Number(searchRow?.count || 0),
    validationErrors: errors,
  }
  return { collections, summary }
}
