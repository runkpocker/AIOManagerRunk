import dns from 'dns/promises'
import net from 'net'
import crypto from 'crypto'

export function normalize(value = '') {
  return String(value)
    .normalize('NFKD')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, '')
}

export function jsonParse(value, fallback = null) {
  if (value == null || value === '') return fallback
  try {
    return typeof value === 'string' ? JSON.parse(value) : value
  } catch {
    return fallback
  }
}

export function now() {
  return Date.now()
}

export function makeId(...parts) {
  return crypto.createHash('sha1').update(parts.join('|')).digest('hex')
}

export function isPrivateIp(ip) {
  if (!net.isIP(ip)) return true
  if (ip === '::1' || ip === '0.0.0.0') return true
  if (ip.startsWith('fc') || ip.startsWith('fd') || ip.startsWith('fe80:')) return true
  if (ip.startsWith('127.') || ip.startsWith('10.') || ip.startsWith('169.254.') || ip.startsWith('192.168.')) return true
  const match = ip.match(/^172\.(\d+)\./)
  if (match && Number(match[1]) >= 16 && Number(match[1]) <= 31) return true
  return false
}

export async function assertSafeManifestUrl(rawUrl, allowPrivate = false) {
  let url
  try {
    url = new URL(String(rawUrl).trim())
  } catch {
    throw new Error('Invalid manifest URL')
  }
  if (!['https:', 'http:'].includes(url.protocol)) throw new Error('Manifest URL must use HTTP or HTTPS')
  if (url.username || url.password) throw new Error('Credentials in manifest URLs are not allowed')
  if (!allowPrivate) {
    if (['localhost', 'localhost.localdomain'].includes(url.hostname.toLowerCase())) {
      throw new Error('Private or local manifest URLs are disabled')
    }
    const addresses = await dns.lookup(url.hostname, { all: true })
    if (!addresses.length || addresses.some((item) => isPrivateIp(item.address))) {
      throw new Error('Private or local manifest URLs are disabled')
    }
  }
  return url.toString()
}

export async function fetchManifest(rawUrl, { timeoutMs = 25000, allowPrivate = false, maxBytes = 2_000_000 } = {}) {
  const url = await assertSafeManifestUrl(rawUrl, allowPrivate)
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        accept: 'application/json',
        'user-agent': 'AIOManager-Nuvio/1.0',
      },
      redirect: 'follow',
    })
    if (!response.ok) throw new Error(`Manifest returned HTTP ${response.status}`)
    const length = Number(response.headers.get('content-length') || 0)
    if (length > maxBytes) throw new Error('Manifest is larger than the configured limit')
    const text = await response.text()
    if (Buffer.byteLength(text, 'utf8') > maxBytes) throw new Error('Manifest is larger than the configured limit')
    const manifest = JSON.parse(text)
    if (!manifest || typeof manifest !== 'object' || !manifest.id || !Array.isArray(manifest.catalogs)) {
      throw new Error('Manifest must contain an id and catalogs array')
    }
    return manifest
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('Manifest request timed out')
    if (error instanceof SyntaxError) throw new Error('Manifest did not return valid JSON')
    throw error
  } finally {
    clearTimeout(timer)
  }
}

export function sourceKey(source) {
  return [source.addonId, source.catalogId, source.type, source.genre || ''].join('|')
}
